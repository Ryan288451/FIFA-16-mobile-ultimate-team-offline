package com.example.fifa16privateserver

import android.content.Context
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.ServerSocket
import java.net.Socket
import kotlin.concurrent.thread

class LocalServer(private val context: Context) {
    private var socket: ServerSocket? = null
    @Volatile private var running = false

    fun isRunning() = running

    fun start() {
        if (running) return
        running = true
        thread {
            try {
                socket = ServerSocket(8080)
                while (running) {
                    val client = socket?.accept() ?: break
                    thread { handle(client) }
                }
            } catch (_: Exception) {
                running = false
            }
        }
    }

    private fun handle(client: Socket) {
        client.use { s ->
            val reader = BufferedReader(InputStreamReader(s.getInputStream()))
            val request = reader.readLine() ?: return
            while (reader.ready()) reader.readLine()
            val path = request.split(" ").getOrNull(1) ?: "/"

            val body = when (path) {
                "/" -> "{"server":"FIFA 16 Private Server","status":"online"}"
                "/api/profile" -> asset("data/profile.json")
                "/api/players" -> asset("data/players.json")
                "/api/teams" -> asset("data/teams.json")
                "/api/squad" -> asset("data/squad.json")
                else -> "{"error":"endpoint_not_found"}"
            }

            val status = if (path == "/" || path.startsWith("/api/")) "200 OK" else "404 Not Found"
            val response = "HTTP/1.1 $status\r\nContent-Type: application/json; charset=utf-8\r\nContent-Length: ${body.toByteArray().size}\r\nConnection: close\r\n\r\n$body"
            s.getOutputStream().write(response.toByteArray())
        }
    }

    private fun asset(name: String): String = try {
        context.assets.open(name).bufferedReader().use { it.readText() }
    } catch (_: Exception) {
        "{"error":"data_not_found"}"
    }

    fun stop() {
        running = false
        try { socket?.close() } catch (_: Exception) {}
        socket = null
    }
}
