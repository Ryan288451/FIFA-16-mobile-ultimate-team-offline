package com.example.fifa16privateserver

import android.app.Activity
import android.os.Bundle
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var server: LocalServer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        server = LocalServer(this)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(40,50,40,40)

        val title = TextView(this)
        title.text = "FIFA 16 PRIVATE SERVER"
        title.textSize = 24f

        status = TextView(this)
        status.text = "Servidor: PARADO"
        status.textSize = 18f
        status.setPadding(0,30,0,30)

        val button = Button(this)
        button.text = "INICIAR SERVIDOR"
        button.setOnClickListener {
            if (server.isRunning()) {
                server.stop()
                button.text = "INICIAR SERVIDOR"
                status.text = "Servidor: PARADO"
            } else {
                server.start()
                button.text = "PARAR SERVIDOR"
                status.text = "Servidor: ONLINE\nhttp://127.0.0.1:8080"
            }
        }

        box.addView(title)
        box.addView(status)
        box.addView(button)
        setContentView(box)
    }

    override fun onDestroy() {
        server.stop()
        super.onDestroy()
    }
}
