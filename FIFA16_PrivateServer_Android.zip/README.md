# FIFA 16 Private Server Android

Projeto de servidor local/offline independente.

Endpoints:
GET /
GET /api/profile
GET /api/players
GET /api/teams
GET /api/squad

Para compilar:
./gradlew assembleDebug

O APK fica em:
app/build/outputs/apk/debug/app-debug.apk

Este projeto não é um servidor oficial da EA.
